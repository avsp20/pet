$(function () {
  var business_users_table = $('#business_users_table').DataTable({
    destroy: true,  
    processing: true,
    serverSide: true,
    ajax: window.location.href,
    columns: [
      {data: 'DT_RowIndex', name: 'DT_RowIndex'},
      {data: 'name', name:'name' },
      {data: 'address', name: 'address' },
      {data: 'phone', name: 'phone' },
      {data: 'status', name: 'status' },
      {data: 'created_by', name: 'created_by' },
      {data: 'updated_by', name: 'updated_by' },
      {data: 'action', name: 'action', orderable: true },
    ]
  });
  var form = $('.validate-form'),
    accountUploadImg = $('#account-upload-img'),
    accountUploadBtn = $('#account-upload'),
    accountUserImage = $('.uploadedAvatar'),
    accountResetBtn = $('#account-reset')

  // Update user photo on click of button

  if (accountUserImage) {
    var resetImage = accountUserImage.attr('src');
    accountUploadBtn.on('change', function (e) {
      var reader = new FileReader(),
        files = e.target.files;
      reader.onload = function () {
        if (accountUploadImg) {
          accountUploadImg.attr('src', reader.result);
        }
      };
      reader.readAsDataURL(files[0]);
    });

    accountResetBtn.on('click', function () {
      accountUserImage.attr('src', resetImage);
    });
  }

  // jQuery Validation for all forms
  // --------------------------------------------------------------------
  if (form.length) {
    form.each(function () {
      var $this = $(this);
      var password = false;
      if(rt == "create"){
        password = true;
      }
      $this.validate({
        rules: {
          business_name: {
            required: true
          },
          name: {
            required: true
          },
          lname: {
            required: true
          },
          email: {
            required: true
          },
          phone: {
            required: true 
          },
          password: {
            required: password
          }
        }
      });
    });
  }
});
function deleteBusinessUser(id) {
  Swal.fire({
    title: 'Are you sure you want to delete business user?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete it!',
    customClass: {
      confirmButton: 'btn btn-primary',
      cancelButton: 'btn btn-outline-danger ms-1'
    },
    buttonsStyling: false
  }).then(function (result) {
    if (result.value) {
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('input[name=_token]').val()
        }
      });
      $.ajax({
        type: "DELETE",
        url:  base_url + `/admin/businesses/${id}`,
        success: function(data) {
          if (data) {
            Swal.fire(
              'Success!',
              data.success,
              'success'
            ).then((result) => {
              $('#business_users_table').DataTable().ajax.reload();
            })
          }
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
          Swal.fire(
            'Error!',
            jqXHR.responseJSON.data,
            'error'
          ).then((result) => {
            if (result.value) {
              location.reload()
            }
          })
        }
      })
    }
  })
}
