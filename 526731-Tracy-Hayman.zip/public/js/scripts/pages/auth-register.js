/*=========================================================================================
  File Name: auth-register.js
  Description: Auth register js file.
  ----------------------------------------------------------------------------------------
  Item Name: Vuexy  - Vuejs, HTML & Laravel Admin Dashboard Template
  Author: PIXINVENT
  Author URL: http://www.themeforest.net/user/pixinvent
==========================================================================================*/

$(function () {
  ;('use strict')

  var assetsPath = '../../../app-assets/',
    registerMultiStepsWizard = document.querySelector('.register-multi-steps-wizard');

  if ($('body').attr('data-framework') === 'laravel') {
    assetsPath = $('body').attr('data-asset-path')
  }

  // multi-steps registration
  // --------------------------------------------------------------------

  // Horizontal Wizard
  if (typeof registerMultiStepsWizard !== undefined && registerMultiStepsWizard !== null) {
    var numberedStepper = new Stepper(registerMultiStepsWizard),
      $form = $(registerMultiStepsWizard).find('form')
    $form.each(function () {
      var $this = $(this)
      $this.validate({
        rules: {
          fname: {
            required: true
          },
          lname: {
            required: true
          },
          phone: {
            required: true
          },
          email: {
            required: true
          },
          fname: {
            required: true
          },
          lname: {
            required: true
          },
          phone: {
            required: true,
            digits: true
          },
          alternate_phone: {
            digits: true
          },
          password: {
            required: true,
            minlength: 8
          },
          confirm_password: {
            required: true,
            minlength: 8,
            equalTo: '#password'
          },
          pet_type: {
            required: true
          },
          gender: {
            required: true
          },
          pet_name: {
            required: true
          },
          age: {
            required: true,
            digits: true
          },
          weight: {
            required: true,
            number: true
          },
          date_of_birth: {
            required: true
          },
          breed_and_color: {
            required: true
          },
        },
        errorPlacement: function (error, element) {
          if(element.attr("name") == "date_of_birth"){
            error.appendTo("#date_of_birth-error");
          }else{
            error.insertAfter(element);
          }
        },
        messages: {
          password: {
            required: 'Enter new password',
            minlength: 'Enter at least 8 characters'
          },
          confirm_password: {
            required: 'Please confirm new password',
            minlength: 'Enter at least 8 characters',
            equalTo: 'The password and its confirm are not the same'
          }
        } 
      })
    })

    $(registerMultiStepsWizard)
      .find('.btn-next')
      .each(function () {
        $(this).on('click', function (e) {
          var isValid = $(this).parent().parent().parent().parent('form').valid()//$(this).parent().siblings('form').valid()
          if (isValid) {
            numberedStepper.next()
          } else {
            e.preventDefault()
          }
        })
      })

    $(registerMultiStepsWizard)
      .find('.btn-prev')
      .on('click', function () {
        numberedStepper.previous()
      })

    $(registerMultiStepsWizard)
      .find('.btn-submit')
      .on('click', function () {
        var isValid = $(this).parent().parent().parent().parent('form').valid()
        if (isValid) {
          alert('Submitted..!!')
        }
      })
  }

})
