$(function () {
  ('use strict');

  // variables
  
});
