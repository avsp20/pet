$(function () {
  var users_table = $('#users_table').DataTable({
    destroy: true,  
    processing: true,
    serverSide: true,
    ajax: window.location.href,
    columns: [
      {data: 'DT_RowIndex', name: 'DT_RowIndex'},
      {data: 'name', name:'name' },
      {data: 'address', name: 'address' },
      {data: 'phone', name: 'phone' },
      {data: 'status', name: 'status' },
      {data: 'action', name: 'action', orderable: true },
    ]
  });
});
function deleteUser(id) {
  Swal.fire({
    title: 'Are you sure you want to delete user?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete it!',
    customClass: {
      confirmButton: 'btn btn-primary',
      cancelButton: 'btn btn-outline-danger ms-1'
    },
    buttonsStyling: false
  }).then(function (result) {
    if (result.value) {
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('input[name=_token]').val()
        }
      });
      $.ajax({
        type: "DELETE",
        url:  base_url + `/admin/users/${id}`,
        success: function(data) {
          if (data) {
            Swal.fire(
              'Success!',
              data.success,
              'success'
            ).then((result) => {
              $('#users_table').DataTable().ajax.reload();
            })
          }
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
          Swal.fire(
            'Error!',
            jqXHR.responseJSON.data,
            'error'
          ).then((result) => {
            if (result.value) {
              location.reload()
            }
          })
        }
      })
    }
  })
}
