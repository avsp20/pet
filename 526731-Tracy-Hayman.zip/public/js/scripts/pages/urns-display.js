$(function(){
  var urn_display_table = $('#urn_display_table').DataTable({
    destroy: true,  
    processing: true,
    serverSide: true,
    ajax: window.location.href,
    columns: [
      {data: 'DT_RowIndex', name: 'DT_RowIndex'},
      {data: 'image', name:'image' },
      {data: 'title', name: 'title' },
      {data: 'status', name: 'status' },
      {data: 'created_at', name: 'created_at' },
      {data: 'action', name: 'action', orderable: false },
    ]
  });
  var form = $('.validate-form'),
    accountUploadImg = $('#account-upload-img'),
    accountUploadBtn = $('#account-upload'),
    accountUserImage = $('.uploadedAvatar'),
    accountResetBtn = $('#account-reset')

  // Update user photo on click of button

  if (accountUserImage) {
    var resetImage = accountUserImage.attr('src');
    accountUploadBtn.on('change', function (e) {
      var reader = new FileReader(),
        files = e.target.files;
      reader.onload = function () {
        if (accountUploadImg) {
          accountUploadImg.attr('src', reader.result);
        }
      };
      reader.readAsDataURL(files[0]);
    });

    accountResetBtn.on('click', function () {
      accountUserImage.attr('src', resetImage);
    });
  }

  // jQuery Validation for all forms
  // --------------------------------------------------------------------
  if (form.length) {
    form.each(function () {
      var $this = $(this);
      var password = false;
      if(rt == "create"){
        password = true;
      }
      $this.validate({
        rules: {
          title: {
            required: true
          },
          status: {
            required: true
          },
          content: {
            required: true
          }
        }
      });
    });
  }
});
function deleteUrnDisplay(id) {
  Swal.fire({
    title: 'Are you sure you want to delete URN?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete it!',
    customClass: {
      confirmButton: 'btn btn-primary',
      cancelButton: 'btn btn-outline-danger ms-1'
    },
    buttonsStyling: false
  }).then(function (result) {
    if (result.value) {
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('input[name=_token]').val()
        }
      });
      $.ajax({
        type: "DELETE",
        url:  base_url + `/admin/urn-display/${id}`,
        success: function(data) {
          if (data) {
            Swal.fire(
              'Success!',
              data.success,
              'success'
            ).then((result) => {
              $('#urn_display_table').DataTable().ajax.reload();
            })
          }
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
          Swal.fire(
            'Error!',
            jqXHR.responseJSON.data,
            'error'
          ).then((result) => {
            if (result.value) {
              location.reload()
            }
          })
        }
      })
    }
  })
}